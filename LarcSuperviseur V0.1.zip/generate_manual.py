from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, white
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    Image as RLImage, KeepTogether
)
from reportlab.lib import colors
import os

# ── Couleurs MD3 exactes du logiciel ───────────────────────────────
C = {
    'primary': HexColor('#0D47A1'),
    'on_primary': HexColor('#FFFFFF'),
    'primary_container': HexColor('#90CAF9'),
    'secondary': HexColor('#00897B'),
    'secondary_container': HexColor('#B2DFDB'),
    'tertiary': HexColor('#E65100'),
    'tertiary_container': HexColor('#FFCC80'),
    'error': HexColor('#C62828'),
    'error_container': HexColor('#FFCDD2'),
    'success': HexColor('#2E7D32'),
    'surface': HexColor('#F5F7FA'),
    'surface_variant': HexColor('#E8EAF6'),
    'card': HexColor('#FFFFFF'),
    'text_strong': HexColor('#1B1B1F'),
    'text_soft': HexColor('#455A64'),
    'text_disabled': HexColor('#90A4AE'),
    'outline': HexColor('#B0BEC5'),
    'outline_variant': HexColor('#B0BEC5'),
    'header_bg': HexColor('#0D47A1'),
    'active': HexColor('#0D47A1'),
    'inactive': HexColor('#90A4AE'),
}

IMG_DIR = os.path.join(os.path.dirname(__file__), 'img')
OUTPUT = os.path.join(os.path.dirname(__file__), 'Mode_d_emploi_LarcSuperviseur.pdf')

styles = {}
def add_style(name, **kw):
    styles[name] = ParagraphStyle(name, **kw)

add_style('CoverTitle', fontName='Helvetica-Bold', fontSize=28, textColor=white, alignment=TA_CENTER, leading=34)
add_style('CoverSub', fontName='Helvetica', fontSize=13, textColor=HexColor('#B0BEC5'), alignment=TA_CENTER, leading=18)
add_style('CoverLine', fontName='Helvetica', fontSize=9, textColor=HexColor('#90CAF9'), alignment=TA_CENTER)
add_style('SectionH1', fontName='Helvetica-Bold', fontSize=18, textColor=C['primary'], spaceBefore=16, spaceAfter=10, leading=22)
add_style('SectionH2', fontName='Helvetica-Bold', fontSize=13, textColor=C['secondary'], spaceBefore=14, spaceAfter=6, leading=17)
add_style('Body', fontName='Helvetica', fontSize=9.5, textColor=C['text_strong'], leading=14, alignment=TA_JUSTIFY, spaceAfter=5)
add_style('Bullet', fontName='Helvetica', fontSize=9.5, textColor=C['text_strong'], leading=14, leftIndent=18, bulletIndent=6, spaceAfter=2)
add_style('Code', fontName='Courier', fontSize=7.5, textColor=C['text_strong'], backColor=C['surface_variant'], borderPadding=6, spaceAfter=5, leading=11)
add_style('Note', fontName='Helvetica', fontSize=9, textColor=C['tertiary'], leading=13)
add_style('TOC', fontName='Helvetica', fontSize=11, textColor=C['text_strong'], leftIndent=10, spaceAfter=4, leading=15)

story = []

def img(name, w=460):
    path = os.path.join(IMG_DIR, name)
    if os.path.exists(path):
        return RLImage(path, width=w, height=w * 0.6, hAlign='CENTER')
    return None

def note_box(text):
    t = Table([[Paragraph(text, styles['Note'])]], colWidths=[460])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), HexColor('#FFF3E0')),
        ('BOX', (0,0), (-1,-1), 1, C['tertiary']),
        ('LEFTPADDING', (0,0), (-1,-1), 12), ('RIGHTPADDING', (0,0), (-1,-1), 12),
        ('TOPPADDING', (0,0), (-1,-1), 8), ('BOTTOMPADDING', (0,0), (-1,-1), 8),
    ]))
    return t

def styled_table(data, col_widths, header=True):
    t = Table(data, colWidths=col_widths)
    style = [
        ('FONTSIZE', (0,0), (-1,-1), 9),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('GRID', (0,0), (-1,-1), 0.5, C['outline']),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
    ]
    if header:
        style += [
            ('BACKGROUND', (0,0), (-1,0), C['primary']),
            ('TEXTCOLOR', (0,0), (-1,0), white),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('FONTNAME', (1,1), (-1,-1), 'Helvetica'),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [C['card'], C['surface']]),
        ]
    t.setStyle(TableStyle(style))
    return t

# ── PAGE DE COUVERTURE ─────────────────────────────────────────────
story.append(Spacer(1, 60*mm))
story.append(Paragraph("LarcSuperviseur", styles['CoverTitle']))
story.append(Spacer(1, 5*mm))
story.append(Paragraph("Mode d'emploi", styles['CoverSub']))
story.append(Paragraph("Application de supervision des présences", styles['CoverSub']))
story.append(Paragraph("et événements élèves", styles['CoverSub']))
story.append(Spacer(1, 25*mm))
story.append(Paragraph("─" * 30, styles['CoverLine']))
story.append(Spacer(1, 8*mm))
story.append(Paragraph("Version 1.0 — Juin 2026", styles['CoverSub']))
story.append(Paragraph("PySide6  ·  PostgreSQL  ·  Material Design 3", styles['CoverLine']))
story.append(PageBreak())

# ── TABLE DES MATIÈRES ─────────────────────────────────────────────
story.append(Paragraph("Table des matières", styles['SectionH1']))
story.append(Spacer(1, 3*mm))
toc_entries = [
    "1. Introduction",
    "2. Installation et démarrage",
    "3. Authentification",
    "4. Interface principale",
    "5. Navigation par section",
    "6. Page Groupe — Tableau de bord",
    "7. Page Classe — Cartes élèves",
    "8. Fiche élève détaillée",
    "9. Gestion des événements",
    "10. Emploi du temps",
    "11. Thèmes et personnalisation",
    "12. Rôles et permissions",
    "13. Dépannage",
    "14. Informations techniques",
]
for e in toc_entries:
    story.append(Paragraph(e, styles['TOC']))
story.append(PageBreak())

# ── 1. INTRODUCTION ────────────────────────────────────────────────
story.append(Paragraph("1. Introduction", styles['SectionH1']))
story.append(Paragraph(
    "LarcSuperviseur est une application desktop dédiée à la supervision de la vie scolaire. "
    "Elle permet de collecter, visualiser et valider les événements de présence et d'absence "
    "des élèves, avec des tableaux de bord interactifs, des graphiques dynamiques et une "
    "gestion fine des rôles utilisateurs.", styles['Body']))

i = img('07_architecture.png', 400)
if i: story.append(i)

story.append(Paragraph("Public cible", styles['SectionH2']))
story.append(Paragraph("• Superviseurs de présence", styles['Bullet']))
story.append(Paragraph("• Coordinateurs pédagogiques", styles['Bullet']))
story.append(Paragraph("• Administrateurs d'établissement", styles['Bullet']))

story.append(Paragraph("Technologies", styles['SectionH2']))
story.append(styled_table([
    ["Interface", "PySide6 (Qt6) — Material Design 3"],
    ["Base de données", "PostgreSQL 15 (Intranet) + Supabase Cloud"],
    ["Connexion", "psycopg2 direct au serveur PostgreSQL"],
    ["OS cible", "Windows desktop"],
], [120, 340]))
story.append(PageBreak())

# ── 2. INSTALLATION ────────────────────────────────────────────────
story.append(Paragraph("2. Installation et démarrage", styles['SectionH1']))
story.append(Paragraph("Prérequis", styles['SectionH2']))
story.append(Paragraph("• Python 3.x installé", styles['Bullet']))
story.append(Paragraph("• Accès au réseau Intranet (ou Internet pour le mode Cloud)", styles['Bullet']))
story.append(Paragraph("• Compte autorisé (Superviseur, Coordinateur ou Administrateur)", styles['Bullet']))

story.append(Paragraph("Procédure d'installation", styles['SectionH2']))
story.append(Paragraph("<b>1.</b> Activer l'environnement virtuel :", styles['Body']))
story.append(Paragraph(".venv\\Scripts\\activate", styles['Code']))
story.append(Paragraph("<b>2.</b> Installer les dépendances :", styles['Body']))
story.append(Paragraph("pip install -r requirements.txt", styles['Code']))

story.append(Paragraph("Démarrage", styles['SectionH2']))
story.append(Paragraph("Depuis le répertoire parent (C:\\Projets) :", styles['Body']))
story.append(Paragraph("python -m LarcSuperviseur", styles['Code']))
story.append(Spacer(1, 3*mm))
story.append(note_box("L'application doit être lancée depuis le répertoire parent (C:\\Projets), pas depuis le dossier LarcSuperviseur."))
story.append(PageBreak())

# ── 3. AUTHENTIFICATION ────────────────────────────────────────────
story.append(Paragraph("3. Authentification", styles['SectionH1']))
story.append(Paragraph(
    "La fenêtre de connexion s'ouvre en mode maximisé avec deux onglets : "
    "Intranet (connexion locale au serveur PostgreSQL) et Cloud (connexion distante via OAuth2 Google).",
    styles['Body']))

i = img('01_login.png', 380)
if i: story.append(i)

story.append(Paragraph("Connexion Intranet", styles['SectionH2']))
story.append(Paragraph("1. Saisir l'adresse email (prenom.nom@votreedu.com)", styles['Bullet']))
story.append(Paragraph("2. Saisir le mot de passe", styles['Bullet']))
story.append(Paragraph("3. Cliquer sur <b>Connexion Intranet</b>", styles['Bullet']))

story.append(Paragraph("Connexion Cloud (Google OAuth2)", styles['SectionH2']))
story.append(Paragraph("1. Cliquer sur <b>Connexion Google</b>", styles['Bullet']))
story.append(Paragraph("2. Authentification via compte @arc-en-ciel.org", styles['Bullet']))
story.append(Paragraph("3. Autoriser l'accès OAuth2", styles['Bullet']))

story.append(Paragraph("Sécurité", styles['SectionH2']))
story.append(styled_table([
    ["Tentatives", "5 échecs maximum avant blocage"],
    ["Blocage", "30 secondes avant nouvelle tentative"],
    ["Mots de passe", "Hachage SHA-256 côté serveur"],
    ["Rôles", "Vérification des droits d'accès"],
], [120, 340]))

story.append(Paragraph("Indicateur réseau", styles['SectionH2']))
story.append(Paragraph("• Intranet ● (vert) — Connexion au serveur local établie", styles['Bullet']))
story.append(Paragraph("• Cloud ● (bleu) — Connexion Internet disponible", styles['Bullet']))
story.append(Paragraph("• Hors ligne — Aucune connexion réseau", styles['Bullet']))
story.append(PageBreak())

# ── 4. INTERFACE ───────────────────────────────────────────────────
story.append(Paragraph("4. Interface principale", styles['SectionH1']))
story.append(Paragraph(
    "L'interface se compose d'un en-tête avec le titre de l'application et le sélecteur de thème, "
    "d'une sidebar latérale pour naviguer entre les sections et programmes, d'une barre de navigation "
    "(breadcrumb) et d'une zone de contenu principal qui s'adapte dynamiquement.", styles['Body']))

i = img('02_interface.png', 460)
if i: story.append(i)

story.append(Paragraph("Structure de l'interface", styles['SectionH2']))
story.append(styled_table([
    ["En-tête", "Titre + sélecteur de thème + horloge + déconnexion"],
    ["Sidebar", "Collège/Lycée → PEI/MYP/DP/DPEn → liste des classes"],
    ["Breadcrumb", "Navigation : Accueil > Section > Programme > Classe"],
    ["Contenu", "Page Groupe → Page Classe → Fiche élève"],
], [100, 360]))
story.append(PageBreak())

# ── 5. NAVIGATION ──────────────────────────────────────────────────
story.append(Paragraph("5. Navigation par section", styles['SectionH1']))
story.append(Paragraph(
    "Dans la sidebar, cliquez sur une section (Collège ou Lycée) pour dérouler les programmes "
    "disponibles, puis sélectionnez un programme (PEI, MYP, DP ou DPEn) et enfin une classe. "
    "Le breadcrumb en haut de l'écran affiche votre chemin hiérarchique et permet de revenir "
    "à n'importe quel niveau en un clic.", styles['Body']))

# ── 6. PAGE GROUPE ─────────────────────────────────────────────────
story.append(Paragraph("6. Page Groupe — Tableau de bord", styles['SectionH1']))
story.append(Paragraph(
    "La page Groupe affiche les indicateurs clés de performance (KPIs) de la classe sélectionnée, "
    "avec des graphiques interactifs pour visualiser les tendances.", styles['Body']))

story.append(Paragraph("Indicateurs (KPIs)", styles['SectionH2']))
story.append(styled_table([
    ["Indicateur", "Description"],
    ["👥 Effectif", "Nombre total d'élèves de la classe"],
    ["📅 Absences", "Total des absences sur la période"],
    ["🚪 Sorties", "Nombre de sorties en cours"],
    ["✅ Présents", "Élèves actuellement présents"],
], [120, 340]))

story.append(Paragraph("Graphiques dynamiques (QtCharts)", styles['SectionH2']))
story.append(Paragraph("• <b>Barres</b> — Absences et sorties par jour sur la période", styles['Bullet']))
story.append(Paragraph("• <b>Courbe de tendance</b> — Évolution des absences sur le trimestre", styles['Bullet']))
story.append(Paragraph("• <b>Donut</b> — Répartition présence/absence en pourcentage", styles['Bullet']))

story.append(Paragraph("Navigation temporelle", styles['SectionH2']))
story.append(Paragraph("Périodes disponibles : <b>Jour</b> · <b>Semaine</b> · <b>Mois</b> · <b>Trimestre</b> (3 mois glissants)", styles['Body']))
story.append(PageBreak())

# ── 7. PAGE CLASSE ─────────────────────────────────────────────────
story.append(Paragraph("7. Page Classe — Cartes élèves", styles['SectionH1']))
story.append(Paragraph(
    "Les élèves sont affichés sous forme de grille de cartes responsives. "
    "Le nombre de colonnes (1 à 8) s'adapte automatiquement à la largeur de la fenêtre.", styles['Body']))

i = img('03_card.png', 160)
if i: story.append(i)

story.append(Paragraph("Contenu d'une carte", styles['SectionH2']))
story.append(Paragraph("• Photo de l'élève (ou avatar avec initiales)", styles['Bullet']))
story.append(Paragraph("• Nom et prénom", styles['Bullet']))
story.append(Paragraph("• Statut : <b>Présent</b> (vert) ou <b>Absent</b> (rouge avec bordure)", styles['Bullet']))
story.append(Paragraph("• Nombre de sorties sur la période", styles['Bullet']))

story.append(Paragraph("Interactions", styles['SectionH2']))
story.append(Paragraph("• <b>Clic</b> sur une carte → ouvre la fiche détaillée", styles['Bullet']))
story.append(Paragraph("• <b>Survol</b> → changement de couleur (effet hover)", styles['Bullet']))
story.append(Paragraph("• Grille responsive : de 1 colonne (écran étroit) à 8 colonnes (grand écran)", styles['Bullet']))
story.append(PageBreak())

# ── 8. FICHE ÉLÈVE ─────────────────────────────────────────────────
story.append(Paragraph("8. Fiche élève détaillée", styles['SectionH1']))
story.append(Paragraph(
    "La fiche élève regroupe toutes les informations et l'historique complet de l'élève "
    "sélectionné.", styles['Body']))

i = img('04_detail.png', 460)
if i: story.append(i)

story.append(Paragraph("Onglet Coordonnées", styles['SectionH2']))
story.append(Paragraph("• Nom complet · Email professionnel et personnel", styles['Bullet']))
story.append(Paragraph("• Téléphone maison et portable · Date d'entrée", styles['Bullet']))
story.append(Paragraph("• Classe actuelle", styles['Bullet']))

story.append(Paragraph("KPIs individuels", styles['SectionH2']))
story.append(styled_table([
    ["KPI", "Description"],
    ["Absences", "Nombre total sur la période"],
    ["Sorties", "Nombre de sorties"],
    ["Total", "Nombre total d'événements"],
], [120, 340]))

story.append(Paragraph("Graphique d'évolution", styles['SectionH2']))
story.append(Paragraph("Courbe des absences sur le trimestre avec axe temporel (QDateTimeAxis).", styles['Body']))

story.append(Paragraph("Liste des événements", styles['SectionH2']))
story.append(Paragraph("Tableau des 20 derniers événements avec type, lieu, matière, date, note, créateur et statut de validation.", styles['Body']))
story.append(PageBreak())

# ── 9. ÉVÉNEMENTS ──────────────────────────────────────────────────
story.append(Paragraph("9. Gestion des événements", styles['SectionH1']))
story.append(Paragraph(
    "L'EventGenerator permet de créer des événements via une sélection hiérarchique "
    "à 3 niveaux, basée sur la table <b>larcauth_type_event</b> (27 types d'événements).", styles['Body']))

i = img('05_event.png', 420)
if i: story.append(i)

story.append(Paragraph("Sélection hiérarchique", styles['SectionH2']))
story.append(styled_table([
    ["Niveau", "Description"],
    ["1 — Catégorie", "🔴 Bureau BI · 🏥 Médical · 🚪 Sortie · 👁 Suivi"],
    ["2 — Sous-type", "Violence, Malaise, Insubordination, Fuite, etc."],
    ["3 — Précision", "Auteur / Victime / Témoin · Envers adulte / élève"],
], [130, 330]))

story.append(Paragraph("Paramètres", styles['SectionH2']))
story.append(Paragraph("• Date/Heure modifiable (par défaut : maintenant)", styles['Bullet']))
story.append(Paragraph("• Classe filtrée", styles['Bullet']))
story.append(Paragraph("• Case <b>En classe</b> avec matière associée", styles['Bullet']))
story.append(Paragraph("• Note libre (≤200 caractères)", styles['Bullet']))

story.append(Paragraph("Actions disponibles", styles['SectionH2']))
story.append(Paragraph("• <b>Ajouter</b> — Bouton dans la fiche élève", styles['Bullet']))
story.append(Paragraph("• <b>Modifier</b> — Double-clic ou clic droit → Modifier", styles['Bullet']))
story.append(Paragraph("• <b>Supprimer</b> — Clic droit → Supprimer", styles['Bullet']))
story.append(Paragraph("• <b>Valider/Dévalider</b> — Clic droit → Valider (COORD/ADMIN)", styles['Bullet']))

story.append(Paragraph("Types d'événements", styles['SectionH2']))
story.append(styled_table([
    ["Type", "Icône", "Couleur"],
    ["arrival (Arrivée)", "▲", "#27ae60"],
    ["departure (Départ)", "▼", "#2980b9"],
    ["exit (Sortie)", "→", "#e67e22"],
    ["absence", "✕", "#e74c3c"],
    ["justified", "✓", "#95a5a6"],
    ["late (Retard)", "⏰", "#f1c40f"],
    ["Bureau BI", "🔴", "#d32f2f"],
    ["Médical", "🏥", "#1976d2"],
    ["Sortie", "🚪", "#e65100"],
    ["Suivi", "👁", "#f9a825"],
], [130, 80, 100]))
story.append(PageBreak())

# ── 10. EMPLOI DU TEMPS ────────────────────────────────────────────
story.append(Paragraph("10. Emploi du temps", styles['SectionH1']))
story.append(Paragraph(
    "Depuis la page classe, cliquez sur <b>Modifier l'emploi du temps</b> pour accéder "
    "à la grille éditable. Les créneaux sont organisés par jour (Lun-Ven) et par horaire.", styles['Body']))
story.append(Paragraph("• <b>Ajouter</b> un créneau : clic sur une cellule vide", styles['Bullet']))
story.append(Paragraph("• <b>Modifier</b> : clic sur un créneau existant", styles['Bullet']))
story.append(Paragraph("• <b>Supprimer</b> : sélectionner puis touche Suppr", styles['Bullet']))

# ── 11. THÈMES ─────────────────────────────────────────────────────
story.append(Paragraph("11. Thèmes et personnalisation", styles['SectionH1']))
story.append(Paragraph(
    "L'application propose 3 thèmes Material Design 3, reconstruisant intégralement "
    "la feuille de style au changement.", styles['Body']))

i = img('06_themes.png', 460)
if i: story.append(i)

story.append(styled_table([
    ["Thème", "Description", "Usage"],
    ["Material Light", "Thème clair par défaut", "Usage en journée"],
    ["Material Dark", "Thème sombre", "Faible luminosité"],
    ["Material Contrast", "Haut contraste", "Accessibilité"],
], [130, 170, 160]))

story.append(Paragraph(
    "Le changement de thème est instantané et ne nécessite pas de redémarrage de l'application.", styles['Body']))
story.append(PageBreak())

# ── 12. RÔLES ──────────────────────────────────────────────────────
story.append(Paragraph("12. Rôles et permissions", styles['SectionH1']))
story.append(styled_table([
    ["Rôle", "Écriture", "Validation", "Lecture Cloud"],
    ["SUPERVISEUR", "✓", "—", "—"],
    ["COORDINATEUR", "✓", "✓", "—"],
    ["ADMINISTRATEUR", "✓", "✓", "✓"],
], [140, 100, 110, 110]))
story.append(Spacer(1, 3*mm))
story.append(Paragraph(
    "Les rôles sont vérifiés lors de la connexion via les colonnes de la table "
    "<b>larcauth_aecuser</b> : <i>type_supervisor</i>, <i>type_coordonator</i>, <i>is_adm</i>.", styles['Body']))

# ── 13. DÉPANNAGE ──────────────────────────────────────────────────
story.append(Paragraph("13. Dépannage", styles['SectionH1']))
story.append(styled_table([
    ["Problème", "Cause", "Solution"],
    ["Connexion Intranet impossible",
     "PostgreSQL indisponible\nou problème réseau",
     "Vérifier la connexion réseau.\nUtiliser le mode Cloud."],
    ["Trop de tentatives",
     "5 échecs consécutifs",
     "Attendre 30 secondes."],
    ["Utilisateur introuvable",
     "Email incorrect\nou compte inexistant",
     "Vérifier l'orthographe.\nContacter l'administrateur."],
    ["Mot de passe incorrect",
     "Mauvais mot de passe",
     "Vérifier la casse.\nContacter l'administrateur."],
    ["Application ne démarre pas",
     "Dépendances manquantes",
     "pip install -r requirements.txt"],
], [120, 140, 200]))

story.append(Paragraph("Logs", styles['SectionH2']))
story.append(Paragraph("Les logs sont écrits dans le fichier <b>superviseur.log</b> à la racine du projet.", styles['Body']))
story.append(PageBreak())

# ── 14. INFOS TECHNIQUES ───────────────────────────────────────────
story.append(Paragraph("14. Informations techniques", styles['SectionH1']))
story.append(Paragraph("Architecture réseau", styles['SectionH2']))
story.append(styled_table([
    ["Composant", "Description"],
    ["Intranet PostgreSQL", "192.168.2.90:5432/NewLarcDB (écriture + lecture)"],
    ["Supabase Cloud", "PostgreSQL via PgBouncer (lecture seule)"],
    ["Sync", "Unidirectionnelle Intranet vers Cloud"],
    ["Client Desktop", "Python PySide6 — psycopg2 direct"],
], [130, 330]))

story.append(Paragraph("Table student_event", styles['SectionH2']))
story.append(styled_table([
    ["Colonne", "Type", "Description"],
    ["event_id", "INTEGER PK", "Auto-généré"],
    ["student_id", "INTEGER FK", "Référence larcauth_student"],
    ["event_type", "TEXT", "Chemin hiérarchique (ex: Suivi > Absence)"],
    ["event_at", "TIMESTAMP", "Horodatage du constat"],
    ["note", "TEXT", "Remarque libre (≤ 200 car.)"],
    ["created_by", "INTEGER FK", "Auteur de l'événement"],
    ["validated_by", "INTEGER FK", "Validateur (NULL = non validé)"],
], [110, 110, 240]))

story.append(Paragraph("Rafraîchissement", styles['SectionH2']))
story.append(Paragraph("L'interface se rafraîchit automatiquement toutes les <b>30 secondes</b> pour afficher les données en temps réel.", styles['Body']))

story.append(Paragraph("Principes fondamentaux", styles['SectionH2']))
story.append(Paragraph("• <b>INSERT only</b> sur student_event — pas de mise à jour ni suppression des traces", styles['Bullet']))
story.append(Paragraph("• <b>Écriture Intranet uniquement</b> — le Cloud est en lecture seule", styles['Bullet']))
story.append(Paragraph("• <b>Mêmes règles métier</b> pour tous les clients (contraintes CHECK + triggers PostgreSQL)", styles['Bullet']))
story.append(Paragraph("• <b>Sync unidirectionnelle</b> Intranet → Cloud", styles['Bullet']))

# ── GÉNÉRATION ─────────────────────────────────────────────────────
def add_bg(canvas, doc):
    canvas.saveState()
    if doc.page == 1:
        canvas.setFillColor(C['primary'])
        canvas.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
        canvas.setStrokeColor(HexColor('#1565C0'))
        canvas.setLineWidth(2)
        canvas.line(30*mm, 55*mm, A4[0] - 30*mm, 55*mm)
    else:
        canvas.setFont('Helvetica', 7.5)
        canvas.setFillColor(C['text_disabled'])
        canvas.drawCentredString(A4[0]/2, 12*mm,
            f"LarcSuperviseur — Mode d'emploi — Page {doc.page}")
    canvas.restoreState()

doc = SimpleDocTemplate(
    OUTPUT, pagesize=A4,
    leftMargin=18*mm, rightMargin=18*mm,
    topMargin=16*mm, bottomMargin=22*mm,
    title="LarcSuperviseur - Mode d'emploi",
    author="Équipe LarcSuperviseur"
)

doc.build(story, onFirstPage=add_bg, onLaterPages=add_bg)
print(f"PDF généré : {OUTPUT}")
