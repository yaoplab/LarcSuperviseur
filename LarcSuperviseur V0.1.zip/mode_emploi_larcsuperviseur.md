# Mode d'Emploi — LarcSuperviseur

## Application de Supervision des Présences et Événements Élèves

---

## Table des matières

1. [Introduction](#1-introduction)
2. [Installation et Démarrage](#2-installation-et-démarrage)
3. [Authentification](#3-authentification)
4. [Interface Principale](#4-interface-principale)
5. [Navigation par Section](#5-navigation-par-section)
6. [Page Groupe](#6-page-groupe)
7. [Page Classe](#7-page-classe)
8. [Fiche Élève](#8-fiche-élève)
9. [Gestion des Événements](#9-gestion-des-événements)
10. [Emploi du Temps](#10-emploi-du-temps)
11. [Thèmes et Personnalisation](#11-thèmes-et-personnalisation)
12. [Rôles et Permissions](#12-rôles-et-permissions)
13. [Dépannage](#13-dépannage)

---

## 1. Introduction

**LarcSuperviseur** est une application desktop dédiée à la supervision de la vie scolaire. Elle permet de :

- **Collecter** les événements de présence/absence des élèves
- **Visualiser** les données via des tableaux de bord et graphiques
- **Valider** les événements selon les rôles utilisateurs
- **Gérer** les emplois du temps et les informations élèves

### Public cible

- Superviseurs de présence
- Coordinateurs pédagogiques
- Administrateurs d'établissement

### Technologies

- **Interface** : PySide6 (Qt6) — Design Material Design 3
- **Base de données** : PostgreSQL (Intranet) + Supabase (Cloud, lecture seule)
- **Connexion** : psycopg2 directe au serveur PostgreSQL

---

## 2. Installation et Démarrage

### Prérequis

- Python 3.x installé
- Accès au réseau Intranet (ou connexion Internet pour le mode Cloud)
- Compte utilisateur autorisé (Superviseur, Coordinateur ou Administrateur)

### Installation

```bash
# 1. Cloner ou accéder au répertoire du projet
cd C:\Projets\LarcSuperviseur

# 2. Activer l'environnement virtuel
.venv\Scripts\activate

# 3. Installer les dépendances
pip install -r requirements.txt
```

### Démarrage

```bash
# Depuis le répertoire PARENT (C:\Projets), PAS depuis LarcSuperviseur/
python -m LarcSuperviseur
```

**Important** : L'application doit être lancée depuis le répertoire parent pour que les imports fonctionnent correctement.

---

## 3. Authentification

### Fenêtre de connexion

L'application s'ouvre en mode maximisé avec deux onglets :

#### Onglet Intranet (connexion locale)

1. Saisir votre **adresse email** (prenom.nom@votreedu.com)
2. Saisir votre **mot de passe**
3. Cliquer sur **"Connexion Intranet"**

#### Onglet Cloud (connexion distante)

1. Cliquer sur **"Connexion Google"**
2. S'authentifier avec votre compte **Google @arc-en-ciel.org**
3. Autoriser l'accès via OAuth2

### Sécurité

- **Limitation de tentatives** : 5 échecs → blocage de 30 secondes
- **Vérification du rôle** : Seuls les Superviseurs, Coordinateurs et Administrateurs ont accès
- **Hachage SHA-256** des mots de passe

### Indicateur de réseau

En bas de la fenêtre de connexion, un indicateur montre l'état de la connexion :
- **Intranet ●** (vert) : Connexion au serveur local réussie
- **Cloud ●** (bleu) : Connexion Internet disponible
- **Hors ligne** (gris) : Aucune connexion

---

## 4. Interface Principale

### Structure de l'interface

L'application se compose de :

```
┌─────────────────────────────────────────────────────────┐
│  En-tête : Titre + Thème + Déconnexion                 │
├──────────┬──────────────────────────────────────────────┤
│          │  Barre de navigation (breadcrumb)           │
│  Sidebar │──────────────────────────────────────────────│
│          │                                              │
│ Sections │         Zone de contenu principal            │
│ Collège  │                                              │
│ Lycée    │    (Groupes → Classes → Fiche Élève)        │
│          │                                              │
└──────────┴──────────────────────────────────────────────┘
```

### Sidebar (menu latéral)

La sidebar contient **2 sections** :

| Section | Programmes |
|---------|------------|
| **Collège** | PEI, MYP |
| **Lycée** | DP, DPEn |

Chaque programme affiche la liste des classes disponibles.

### Barre d'outils

- **Sélecteur de thème** : Material Light / Dark / Contrast
- **Bouton déconnexion** : Retour à la fenêtre de connexion
- **Date/heure** : Affichage en temps réel

---

## 5. Navigation par Section

### Sélection d'une classe

1. **Cliquer** sur le nom d'une section dans la sidebar (ex: "Collège")
2. **Sélectionner** un programme (ex: "MYP")
3. **Cliquer** sur le nom d'une classe

### Barre de navigation (breadcrumb)

La barre de navigation affiche le chemin :
```
Accueil > [Section] > [Programme] > [Classe]
```

Pour revenir en arrière, cliquer sur un élément du breadcrumb.

---

## 6. Page Groupe

### Tableau de bord (KPIs)

En haut de la page, affichage de **4 indicateurs clés** :

| KPI | Description |
|-----|-------------|
| 👥 Effectif | Nombre total d'élèves dans la classe |
| 📅 Absences | Nombre d'absences sur la période |
| 🚪 Sorties | Nombre de sorties en cours |
| ✅ Présents | Nombre d'élèves présents |

### Graphiques

La page groupe affiche **3 types de graphiques** :

#### 1. Barres d'absences/sorties
- Affiche la répartition des absences et sorties par jour
- Période sélectionnable : Jour / Semaine / Mois / Trimestre

#### 2. Courbe de tendance
- Évolution des absences sur le trimestre
- Identification des patterns récurrents

#### 3. Donut de présence
- Répartition pourcentage présence/absence
- Vue d'ensemble rapide

### Navigation temporelle

Utiliser les boutons pour changer la période :
- **Jour** : Aujourd'hui uniquement
- **Semaine** : Lun-Dim en cours
- **Mois** : Mois en cours
- **Trimestre** : 3 derniers mois glissants

---

## 7. Page Classe

### Cartes élèves

Affichage sous forme de **grille de cartes** (1 à 8 colonnes selon la taille de l'écran).

#### Chaque carte contient :
- **Photo** de l'élève (ou avatar avec initiales si pas de photo)
- **Nom et prénom**
- **Statut** : Présent (vert) / Absent (rouge)
- **Nombre de sorties** sur la période

#### Interactions :
- **Cliquer** sur une carte → Ouvre la fiche détaillée de l'élève
- **Survol** : La carte change de couleur pour indiquer qu'elle est interactive

### Organisation responsive

La grille s'adapte automatiquement à la taille de la fenêtre :
- Écran large : 8 colonnes
- Écran moyen : 4-6 colonnes
- Écran étroit : 1-3 colonnes

---

## 8. Fiche Élève

### Accès

Cliquer sur la carte d'un élève dans la page classe.

### Contenu de la fiche

#### Onglet Coordonnées
- **Nom complet**
- **Email** professionnel
- **Email** personnel
- **Téléphone** maison
- **Téléphone** portable
- **Date d'entrée** dans l'établissement
- **Classe** actuelle

#### Photo
- Affichage en 150×150 pixels
- Photo par défaut si absente

#### KPIs de l'élève
| Indicateur | Description |
|------------|-------------|
| Absences | Nombre total sur la période |
| Sorties | Nombre de sorties |
| Total events | Nombre total d'événements |

#### Graphique d'évolution
- Courbe des absences sur le trimestre
- Identification des tendances

#### Liste des événements
Tableau des 20 derniers événements avec :
- **Type** (avec icône et couleur)
- **Lieu**
- **Matière**
- **Date/Heure**
- **Note**
- **Créé par**
- **Validé** (✓ si validé)

---

## 9. Gestion des Événements

### Créer un événement

1. **Sélectionner** un élève (cliquer sur sa carte)
2. Cliquer sur le bouton **"Ajouter un événement"**
3. Remplir le formulaire :

#### Sélection hiérarchique (3 niveaux)

L'EventGenerator utilise une sélection progressive depuis `larcauth_type_event` :

**Niveau 1 — Catégorie** (4 boutons) :
| Icône | Catégorie |
|-------|-----------|
| 🔴 | Bureau BI |
| 🏥 | Médical |
| 🚪 | Sortie |
| 👁 | Suivi |

**Niveau 2 — Sous-type** (apparaît au clic) :
- Violence, Malaise, Insubordination, etc.

**Niveau 3 — Précision** (apparaît au clic) :
- Auteur/Victime/Témoin, Envers adulte/élève, etc.

#### Paramètres de l'événement

- **Date/Heure** : Éditable (par défaut = maintenant)
- **Classe** : Sélection filtrée
- **En classe** : Coché par défaut
- **Matière** : Si lié à un cours
- **Note** : Remarque libre (≤200 caractères)

### Types d'événements

| Type | Description | Icône | Couleur |
|------|-------------|-------|---------|
| `arrival` | Arrivée | ▲ | Vert |
| `departure` | Départ | ▼ | Bleu |
| `exit` | Sortie | → | Orange |
| `return` | Retour | ← | Vert clair |
| `absence` | Absence | ✕ | Rouge |
| `justified` | Justifié | ✓ | Gris |
| `late` | Retard | ⏰ | Jaune |
| `Bureau BI > ...` | Incidents | 🔴 | Rouge foncé |
| `Médical > ...` | Médical | 🏥 | Bleu |
| `Sortie > ...` | Sorties | 🚪 | Orange foncé |
| `Suivi > ...` | Suivi | 👁 | Jaune foncé |

### Modifier un événement

1. **Double-cliquer** sur une ligne dans le tableau des événements
2. Ou **clic droit** → "Modifier"
3. Modifier le type et/ou la note
4. Cliquer sur **"Enregistrer"**

### Supprimer un événement

1. **Clic droit** sur l'événement dans le tableau
2. Sélectionner **"Supprimer""**
3. Confirmer la suppression

### Valider/Dévalider un événement

**Réservé aux Coordinateurs et Administrateurs**

1. **Clic droit** sur l'événement
2. Sélectionner **"Valider"** ou **"Dévalider"**
3. La validation est enregistrée avec votre identifiant

---

## 10. Emploi du Temps

### Accès

Depuis la page classe, cliquer sur **"Modifier l'emploi du temps"**.

### Fonctionnalités

- **Grille modifiable** : Créneaux horaires × Jours
- **Ajouter** un créneau : Clic sur une cellule vide
- **Modifier** un créneau : Clic sur un créneau existant
- **Supprimer** : Sélectionner puis touche Supprimer

### Structure

| Colonne | Description |
|---------|-------------|
| Horaire | Créneau horaire (8h-18h) |
| Lundi-Vendredi | Cours assignés |

---

## 11. Thèmes et Personnalisation

### Thèmes disponibles

L'application propose **3 thèmes Material Design 3** :

| Thème | Description | Utilisation |
|-------|-------------|-------------|
| **Material Light** | Thème clair par défaut | Usage en journée |
| **Material Dark** | Thème sombre | Faible luminosité |
| **Material Contrast** | Fort contraste | Accessibilité |

### Changer de thème

1. Cliquer sur le **sélecteur de thème** dans la barre d'outils
2. Sélectionner le thème souhaité
3. L'application se reconstruit immédiatement

### Caractéristiques des thèmes

Chaque thème définit :
- **Palette de couleurs** : primary, secondary, tertiary, error, surface, etc.
- **Échelle de polices** : Tailles de base, petits titres, en-têtes
- **Bordures et contours** : Style des éléments interactifs

---

## 12. Rôles et Permissions

### Tableau des permissions

| Rôle | Écriture | Validation | Lecture Cloud |
|------|----------|------------|---------------|
| **SUPERVISEUR** | ✅ | ❌ | ❌ |
| **COORD** | ✅ | ✅ | ❌ |
| **ADMIN** | ✅ | ✅ | ✅ |

### Détail des permissions

#### SUPERVISEUR
- Créer des événements
- Modifier les événements qu'il a créés
- Supprimer ses propres événements
- Accès en écriture à la base Intranet

#### COORD (Coordinateur)
- Toutes les permissions SUPERVISEUR
- **Valider** les événements des autres utilisateurs
- **Dévalider** les événements validés
- Accès en écriture à la base Intranet

#### ADMIN (Administrateur)
- Toutes les permissions COORD
- **Accès en lecture** à la base Cloud
- Visibilité sur tous les établissements
- Gestion complète des données

### Vérification du rôle

Le rôle est vérifié lors de la connexion via les colonnes :
- `type_supervisor = TRUE` → SUPERVISEUR
- `type_coordonator = TRUE` → COORD
- `is_adm = TRUE` → ADMIN

---

## 13. Dépannage

### Problèmes courants

#### "Impossible de se connecter à l'Intranet"

**Causes possibles** :
- Serveur PostgreSQL indisponible
- Problème réseau
- Identifiants incorrects

**Solutions** :
1. Vérifier la connexion réseau
2. Contacter l'administrateur système
3. Utiliser le mode Cloud si disponible

#### "Trop de tentatives"

**Cause** : 5 échecs de connexion consécutifs

**Solution** : Attendre 30 secondes puis réessayer

#### "Utilisateur introuvable"

**Causes possibles** :
- Adresse email incorrecte
- Compte non créé dans la base

**Solutions** :
1. Vérifier l'orthographe de l'email
2. Contacter l'administrateur pour créer le compte

#### "Mot de passe incorrect"

**Solutions** :
1. Vérifier la casse (majuscules/minuscules)
2. Utiliser "Mot de passe oublié" si disponible
3. Contacter l'administrateur

#### Application ne s'ouvre pas

**Causes possibles** :
- Python non installé ou non dans le PATH
- Dépendances manquantes

**Solutions** :
```bash
# Vérifier Python
python --version

# Réinstaller les dépendances
pip install -r requirements.txt
```

#### Photos non affichées

**Cause** : Fichiers PNG manquants dans `photos/`

**Solution** : Vérifier que les photos existent au format `{student_id}.png` (500×500, fond transparent)

---

## Informations Techniques

### Architecture

```
PostgreSQL Intranet (192.168.2.90:5432/NewLarcDB)
        ↕
┌──────────────────┐    ┌──────────────────┐
│ Desktop PySide6  │    │ Mobile Flutter   │
│ (école)          │    │ (école, WiFi)    │
│ psycopg2 direct  │    │ PgBouncer direct │
└──────────────────┘    └──────────────────┘
        │                        │
        └────────┬───────────────┘
                 ↓
        ┌──────────────────┐
        │ Supabase Cloud   │
        │ (lecture seule)  │
        └──────────────────┘
```

### Base de données

#### Table `student_event`
| Colonne | Type | Description |
|---------|------|-------------|
| event_id | INTEGER PK | Auto-généré |
| student_id | INTEGER FK | Référence élève |
| event_type | TEXT | Chemin hiérarchique ou ancien mot-clé |
| event_at | TIMESTAMP | Horodatage du constat |
| note | TEXT | Remarque libre |
| created_by | INTEGER FK | Auteur de l'événement |
| validated_by | INTEGER FK | Validateur (NULL si non validé) |

#### Table `larcauth_type_event`
| Colonne | Type | Description |
|---------|------|-------------|
| idtypeevent | SMALLINT PK | 100-499 |
| type_event | VARCHAR | Catégorie niveau 1 |
| Event_Niveau2 | VARCHAR | Sous-type |
| Event_Niveau3 | VARCHAR | Précision |
| Enabled | BOOLEAN | Activation |

### Rafraîchissement

L'application se rafraîchit **automatiquement toutes les 30 secondes** pour afficher les données les plus récentes.

---

## Support

Pour toute question ou problème :

1. Consulter cette documentation
2. Vérifier les logs dans `superviseur.log`
3. Contacter l'administrateur système

---

**Version** : 1.0  
**Dernière mise à jour** : Juin 2026  
**Développeur** : Équipe LarcSuperviseur
