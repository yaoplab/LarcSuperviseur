from PIL import Image, ImageDraw, ImageFont
import os, math

OUT = os.path.join(os.path.dirname(__file__), 'img')
os.makedirs(OUT, exist_ok=True)

# Couleurs MD3 du logiciel
MD3 = {
    'primary': '#0D47A1', 'primary_container': '#90CAF9',
    'secondary': '#00897B', 'secondary_container': '#B2DFDB',
    'tertiary': '#E65100', 'tertiary_container': '#FFCC80',
    'error': '#C62828', 'error_container': '#FFCDD2',
    'success': '#2E7D32',
    'surface': '#F5F7FA', 'surface_variant': '#E8EAF6',
    'card': '#FFFFFF',
    'text': '#1B1B1F', 'text_soft': '#455A64', 'text_disabled': '#90A4AE',
    'outline': '#B0BEC5', 'header_bg': '#0D47A1',
    'on_primary': '#FFFFFF', 'on_error': '#FFFFFF',
}

def font(size):
    try:
        return ImageFont.truetype("C:\\Windows\\Fonts\\segoeui.ttf", size)
    except:
        return ImageFont.load_default()

def font_bold(size):
    try:
        return ImageFont.truetype("C:\\Windows\\Fonts\\seguibd.ttf", size)
    except:
        return ImageFont.load_default()

def rrect(draw, xy, r, **kw):
    x1,y1,x2,y2 = xy
    r = min(r, (x2-x1)//2, (y2-y1)//2)
    if r <= 0:
        draw.rectangle(xy, **kw)
        return
    draw.pieslice((x1,y1,x1+r*2,y1+r*2), 180, 270, **kw)
    draw.pieslice((x2-r*2,y1,x2,y1+r*2), 270, 360, **kw)
    draw.pieslice((x1,y2-r*2,x1+r*2,y2), 90, 180, **kw)
    draw.pieslice((x2-r*2,y2-r*2,x2,y2), 0, 90, **kw)
    draw.rectangle((x1+r,y1,x2-r,y1+r), **kw)
    draw.rectangle((x1+r,y2-r,x2-r,y2), **kw)
    draw.rectangle((x1,y1+r,x1+r,y2-r), **kw)
    draw.rectangle((x2-r,y1+r,x2,y2-r), **kw)

def sha(x,y,w,h,n=4):
    """Simple shadow rect"""
    return (x+n, y+n, x+w+n, y+h+n)

def drop_shadow(draw, x, y, w, h, r=8, alpha=30):
    for i in range(3):
        a = max(0, alpha - i*8)
        c = (0, 0, 0, a)
        rrect(draw, (x+2+i, y+2+i, x+w-2+i, y+h-2+i), r, fill=c)

# ── 1. FENÊTRE DE CONNEXION ───────────────────────────────────────
img = Image.new('RGBA', (480, 420), MD3['surface'])
d = ImageDraw.Draw(img)

title_f = font_bold(22)
sub_f = font(11)
d.text((240, 40), "LarcSuperviseur", fill=MD3['text'], font=title_f, anchor="mt")
d.text((240, 65), "Supervision de la vie scolaire", fill=MD3['text_soft'], font=sub_f, anchor="mt")

# Tabs
d.rectangle((60, 100, 260, 128), fill=MD3['card'])
d.rectangle((60, 100, 260, 128), fill=MD3['surface'])
d.text((160, 114), "Intranet", fill=MD3['primary'], font=font_bold(11), anchor="mt")
d.line((100, 126, 220, 126), fill=MD3['primary'], width=2)

d.rectangle((260, 100, 420, 128), fill=MD3['surface_variant'])
d.text((340, 114), "Cloud", fill=MD3['text_soft'], font=font(11), anchor="mt")

# Form
d.text((120, 150), "Email :", fill=MD3['text'], font=font(11), anchor="lt")
d.rectangle((120, 168, 360, 192), fill=MD3['card'], outline=MD3['outline'])
d.text((128, 176), "prenom.nom@votreedu.com", fill=MD3['text_disabled'], font=font(10), anchor="lt")
d.text((120, 210), "Mot de passe :", fill=MD3['text'], font=font(11), anchor="lt")
d.rectangle((120, 228, 360, 252), fill=MD3['card'], outline=MD3['outline'])

# Button
rrect(d, (120, 280, 360, 324), 6, fill=MD3['primary'])
d.text((240, 302), "Connexion Intranet", fill='white', font=font_bold(12), anchor="mt")

# Status
d.text((240, 360), "Intranet ●", fill=MD3['success'], font=font_bold(11), anchor="mt")

img.save(os.path.join(OUT, '01_login.png'))
print("01_login.png OK")

# ── 2. INTERFACE PRINCIPALE ────────────────────────────────────────
img = Image.new('RGBA', (800, 500), MD3['surface'])
d = ImageDraw.Draw(img)

# Header
d.rectangle((0,0,800,48), fill=MD3['header_bg'])
d.text((20, 24), "LarcSuperviseur", fill='white', font=font_bold(14), anchor="lm")
d.text((780, 24), "9:30", fill=MD3['text_disabled'], font=font(11), anchor="rm")

# Sidebar
d.rectangle((0,48,180,500), fill=MD3['surface_variant'])
d.text((16, 60), "Collège", fill=MD3['primary'], font=font_bold(12), anchor="lt")
rrect(d, (16, 80, 164, 108), 6, fill=MD3['primary'])
d.text((90, 94), "PEI", fill='white', font=font_bold(11), anchor="mt")
rrect(d, (16, 114, 164, 142), 6, fill=MD3['primary'])
d.text((90, 128), "MYP", fill='white', font=font_bold(11), anchor="mt")
d.text((16, 160), "Lycée", fill=MD3['primary'], font=font_bold(12), anchor="lt")
rrect(d, (16, 180, 164, 208), 6, fill=MD3['surface'])
d.text((90, 194), "DP", fill=MD3['text'], font=font_bold(11), anchor="mt")
rrect(d, (16, 214, 164, 242), 6, fill=MD3['surface'])
d.text((90, 228), "DPEn", fill=MD3['text'], font=font_bold(11), anchor="mt")

# Breadcrumb
d.text((196, 58), "Accueil > Lycée > DP > DP-1En", fill=MD3['text_soft'], font=font(10), anchor="lt")

# KPI cards
kpi_labels = ["👥 24", "📅 3", "🚪 2", "✅ 21"]
kpi_cols = [MD3['primary'], MD3['error'], MD3['tertiary'], MD3['success']]
kpi_bgs = [MD3['primary_container'], MD3['error_container'], MD3['tertiary_container'], MD3['secondary_container']]
for i, (label, col, bg) in enumerate(zip(kpi_labels, kpi_cols, kpi_bgs)):
    x = 196 + i*155
    rrect(d, (x, 78, x+145, 118), 8, fill=bg)
    d.text((x+10, 88), label, fill=col, font=font_bold(16), anchor="lt")
    titles = ["Effectif", "Absences", "Sorties", "Présents"]
    d.text((x+10, 106), titles[i], fill=MD3['text_soft'], font=font(9), anchor="lt")

# Chart area placeholder
rrect(d, (196, 138, 480, 300), 8, fill=MD3['card'], outline=MD3['outline'])
d.text((338, 218), "📊 Graphiques", fill=MD3['text_disabled'], font=font(14), anchor="mt")

# Student cards in right area
card_data = [
    ("DUPONT", "Jean", "✓", MD3['success']),
    ("MARTIN", "Paul", "✗", MD3['error']),
    ("DURAND", "Marie", "✓", MD3['success']),
    ("PETIT", "Lucas", "✓", MD3['success']),
]
for i, (nom, prenom, status, sc) in enumerate(card_data):
    x = 500 + (i%2)*150
    y = 78 + (i//2)*180
    drop_shadow(d, x, y, 140, 165)
    rrect(d, (x, y, x+140, y+165), 8, fill=MD3['card'], outline=MD3['outline'])
    rrect(d, (x+20, y+15, x+120, y+95), 12, fill=MD3['primary_container'])
    initials = nom[0]+prenom[0]
    d.text((x+70, y+55), initials, fill=MD3['on_primary'], font=font_bold(30), anchor="mm")
    f_size = 11 if len(nom) < 8 else 9
    d.text((x+70, y+110), f"{nom} {prenom}", fill=MD3['text'], font=font_bold(f_size), anchor="mt")
    if status == "✓":
        rrect(d, (x+35, y+135, x+105, y+150), 8, fill=MD3['success'])
        d.text((x+70, y+142), "Présent", fill='white', font=font_bold(8), anchor="mt")
    else:
        rrect(d, (x+35, y+135, x+105, y+150), 8, fill=MD3['error'])
        d.text((x+70, y+142), "Absent", fill='white', font=font_bold(8), anchor="mt")

img.save(os.path.join(OUT, '02_interface.png'))
print("02_interface.png OK")

# ── 3. CARTE ÉLÈVE ────────────────────────────────────────────────
img = Image.new('RGBA', (160, 200), MD3['card'])
d = ImageDraw.Draw(img)
rrect(d, (0,0,160,200), 8, outline=MD3['outline'])

d.text((80, 16), "DUPONT", fill=MD3['text'], font=font_bold(13), anchor="mt")
d.text((80, 28), "Jean", fill=MD3['text_soft'], font=font(12), anchor="mt")

rrect(d, (25, 40, 135, 150), 12, fill=MD3['primary_container'])
d.text((80, 95), "DJ", fill=MD3['on_primary'], font=font_bold(36), anchor="mm")

rrect(d, (45, 165, 115, 185), 10, fill=MD3['success'])
d.text((80, 175), "Présent", fill='white', font=font_bold(10), anchor="mt")

img.save(os.path.join(OUT, '03_card.png'))
print("03_card.png OK")

# ── 4. FICHE ÉLÈVE ────────────────────────────────────────────────
img = Image.new('RGBA', (600, 400), MD3['surface'])
d = ImageDraw.Draw(img)

# Photo + Name area
rrect(d, (20, 20, 170, 170), 12, fill=MD3['primary_container'])
d.text((95, 95), "DJ", fill=MD3['on_primary'], font=font_bold(40), anchor="mm")
d.text((190, 40), "Jean DUPONT", fill=MD3['text'], font=font_bold(18), anchor="lt")
d.text((190, 65), "DP-1En", fill=MD3['text_soft'], font=font(12), anchor="lt")

# Contact info
contact_y = 100
labels = [
    ("Email :", "jean.dupont@ecole.com"),
    ("Tél. :", "06 12 34 56 78"),
    ("Entrée :", "01/09/2024"),
]
for j, (l, v) in enumerate(labels):
    y = contact_y + j*25
    d.text((190, y), l, fill=MD3['primary'], font=font_bold(10), anchor="lt")
    d.text((260, y), v, fill=MD3['text'], font=font(10), anchor="lt")

# KPIs
kpi_info = [("Absences", "3", MD3['error']), ("Sorties", "2", MD3['tertiary']), ("Total", "8", MD3['primary'])]
for i, (l, v, c) in enumerate(kpi_info):
    x = 20 + i*130
    rrect(d, (x, 200, x+120, 240), 8, fill=MD3['card'], outline=MD3['outline'])
    d.text((x+60, 216), v, fill=c, font=font_bold(22), anchor="mm")
    d.text((x+60, 232), l, fill=MD3['text_soft'], font=font(9), anchor="mt")

# Events table header
d.text((20, 260), "Derniers événements", fill=MD3['primary'], font=font_bold(12), anchor="lt")
# Table header
cols = [20, 100, 200, 310, 420]
headers = ["Date", "Type", "Note", "Créé par", "Validé"]
for ci, cx in enumerate(cols):
    nx = cols[ci+1] if ci < len(cols)-1 else 580
    d.text((cx+4, 282), headers[ci], fill=MD3['text_soft'], font=font_bold(9), anchor="lt")
d.line((20, 296, 580, 296), fill=MD3['outline'])

events = [
    ("10/06 14:30", "🔴 Bureau BI", "Incident signalé", "P. LABONNE", "✓"),
    ("10/06 10:00", "🚪 Sortie", "Rendez-vous médecin", "P. LABONNE", ""),
    ("09/06 08:30", "✕ Absence", "Non justifiée", "P. LABONNE", ""),
]
for ri, (dt, tp, nt, cr, vl) in enumerate(events):
    ry = 300 + ri*24
    vals = [dt, tp, nt, cr, vl]
    for ci, (cx, val) in enumerate(zip(cols, vals)):
        nx = cols[ci+1] if ci < len(cols)-1 else 580
        c = MD3['error'] if 'Bureau' in tp else MD3['tertiary'] if 'Sortie' in tp else MD3['text']
        d.text((cx+4, ry+4), val, fill=c if ci == 1 else MD3['text'], font=font(9), anchor="lt")

img.save(os.path.join(OUT, '04_detail.png'))
print("04_detail.png OK")

# ── 5. EVENT GENERATOR ─────────────────────────────────────────────
img = Image.new('RGBA', (450, 350), MD3['surface'])
d = ImageDraw.Draw(img)

d.text((20, 20), "Nouvel événement — Jean DUPONT", fill=MD3['text'], font=font_bold(14), anchor="lt")
d.text((20, 42), "Catégorie :", fill=MD3['text_soft'], font=font(11), anchor="lt")

# 4 category buttons
cats = [("🔴 Bureau BI", MD3['error']), ("🏥 Médical", MD3['primary']),
         ("🚪 Sortie", MD3['tertiary']), ("👁 Suivi", MD3['primary_container'])]
for i, (label, col) in enumerate(cats):
    x = 20 + i*105
    rrect(d, (x, 58, x+100, 92), 8, fill=col)
    tc = 'white' if i < 3 else MD3['text']
    d.text((x+50, 75), label, fill=tc, font=font_bold(9), anchor="mm")

# Sub-options (Niveau 2)
d.text((20, 108), "Sous-type :", fill=MD3['text_soft'], font=font(11), anchor="lt")
subs = ["Violence", "Malaise", "Insubordination"]
for i, label in enumerate(subs):
    x = 20 + i*130
    rrect(d, (x, 124, x+125, 152), 6, fill=MD3['card'], outline=MD3['primary'])
    d.text((x+62, 138), label, fill=MD3['primary'], font=font_bold(10), anchor="mm")

# Selected
d.text((20, 170), "Précision (Niveau 3) :", fill=MD3['text_soft'], font=font(11), anchor="lt")
precisions = ["Auteur", "Victime", "Témoin"]
colors3 = [MD3['primary'], MD3['primary_container'], MD3['primary_container']]
for i, (label, col) in enumerate(zip(precisions, colors3)):
    x = 20 + i*100
    rrect(d, (x, 186, x+95, 214), 6, fill=col)
    tc = 'white' if i == 0 else MD3['primary']
    d.text((x+47, 200), label, fill=tc, font=font_bold(10), anchor="mm")

# Note
d.text((20, 234), "Note :", fill=MD3['text_soft'], font=font(11), anchor="lt")
rrect(d, (20, 250, 350, 290), 6, fill=MD3['card'], outline=MD3['outline'])
d.text((28, 258), "Description de l'incident...", fill=MD3['text_disabled'], font=font(10), anchor="lt")

# Buttons
rrect(d, (250, 310, 340, 340), 6, fill=MD3['primary'])
d.text((295, 325), "Enregistrer", fill='white', font=font_bold(11), anchor="mm")
rrect(d, (350, 310, 430, 340), 6, fill=MD3['surface_variant'])
d.text((390, 325), "Annuler", fill=MD3['text'], font=font(11), anchor="mm")

img.save(os.path.join(OUT, '05_event.png'))
print("05_event.png OK")

# ── 6. THÈMES ──────────────────────────────────────────────────────
img = Image.new('RGBA', (600, 120), MD3['surface'])
d = ImageDraw.Draw(img)

d.text((16, 10), "Thèmes disponibles :", fill=MD3['text'], font=font_bold(12), anchor="lt")

themes = [
    ("Material Light", MD3['primary'], MD3['surface']),
    ("Material Dark", '#1B1B1F', '#2D2D31'),
    ("Material Contrast", '#003258', MD3['surface']),
]
for i, (name, prim, surf) in enumerate(themes):
    x = 16 + i*195
    rrect(d, (x, 32, x+185, 100), 10, fill=surf, outline=MD3['outline'])
    d.text((x+92, 42), name, fill=MD3['text'], font=font_bold(11), anchor="mt")
    # Mini preview
    rrect(d, (x+10, 56, x+175, 60), 3, fill=prim)
    rrect(d, (x+10, 64, x+80, 80), 4, fill=surf, outline=MD3['outline'])
    rrect(d, (x+90, 64, x+175, 76), 3, fill=prim)
    d.rectangle((x+90, 80, x+175, 84), fill=MD3['outline'])

img.save(os.path.join(OUT, '06_themes.png'))
print("06_themes.png OK")

# ── 7. SCHÉMA ARCHITECTURE ─────────────────────────────────────────
img = Image.new('RGBA', (500, 300), MD3['surface'])
d = ImageDraw.Draw(img)

d.text((250, 10), "Architecture système", fill=MD3['text'], font=font_bold(14), anchor="mt")

# PostgreSQL at top
rrect(d, (150, 30, 350, 70), 10, fill=MD3['primary'])
d.text((250, 50), "PostgreSQL Intranet", fill='white', font=font_bold(11), anchor="mm")
d.text((250, 68), "192.168.2.90:5432", fill=MD3['text_disabled'], font=font(8), anchor="mt")

# Arrow down
for y in range(75, 95, 4):
    d.line((250, y, 250, y+3), fill=MD3['primary'], width=2)
# Arrow head
d.polygon([(245, 95), (255, 95), (250, 103)], fill=MD3['primary'])

# Desktop app
rrect(d, (50, 105, 250, 155), 10, fill=MD3['secondary'])
d.text((150, 130), "Desktop PySide6", fill='white', font=font_bold(10), anchor="mm")
d.text((150, 145), "psycopg2 direct", fill=MD3['text_disabled'], font=font(8), anchor="mt")

# Mobile app
rrect(d, (250, 105, 450, 155), 10, fill=MD3['tertiary'])
d.text((350, 130), "Mobile Flutter", fill='white', font=font_bold(10), anchor="mm")
d.text((350, 145), "PgBouncer direct", fill=MD3['text_disabled'], font=font(8), anchor="mt")

# Arrow down from both
for y in range(155, 175, 4):
    d.line((150, y, 150, y+3), fill=MD3['secondary'], width=2)
    d.line((350, y, 350, y+3), fill=MD3['tertiary'], width=2)
d.line((150, 175, 350, 175), fill=MD3['outline'], width=1)
d.polygon([(345, 175), (355, 175), (350, 183)], fill=MD3['primary'])
for y in range(175, 195, 4):
    d.line((250, y, 250, y+3), fill=MD3['primary'], width=2)
d.polygon([(245, 195), (255, 195), (250, 203)], fill=MD3['primary'])

# Cloud
rrect(d, (100, 205, 400, 255), 10, fill=MD3['primary_container'])
d.text((250, 230), "Supabase Cloud (lecture seule)", fill=MD3['primary'], font=font_bold(11), anchor="mm")

# Browser
rrect(d, (150, 265, 350, 295), 8, fill=MD3['surface_variant'])
d.text((250, 280), "🌐 Accès navigateur (admin, maison)", fill=MD3['text'], font=font(9), anchor="mm")

img.save(os.path.join(OUT, '07_architecture.png'))
print("07_architecture.png OK")

print(f"\n✅ {len(os.listdir(OUT))} images générées dans {OUT}")
